﻿JogoDaVelha jogo = new JogoDaVelha();

jogo.Iniciar();